<?php

namespace App\Services;

class HotelService {

}
